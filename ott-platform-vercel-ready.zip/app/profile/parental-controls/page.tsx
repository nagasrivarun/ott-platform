"use client"

import { useState } from "react"
import { MainNav } from "@/components/navigation/main-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { Shield, Lock, Clock, Filter } from "lucide-react"

export default function ParentalControlsPage() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [pin, setPin] = useState("")
  const [confirmPin, setConfirmPin] = useState("")
  const [kidsMode, setKidsMode] = useState(true)
  const [maxAgeRating, setMaxAgeRating] = useState([7])
  const [contentFilters, setContentFilters] = useState({
    violence: true,
    language: true,
    nudity: true,
    substances: true,
  })
  const [timeRestrictions, setTimeRestrictions] = useState({
    enabled: false,
    dailyLimit: 120, // minutes
    bedtime: "21:00",
  })

  const handleSavePin = () => {
    if (pin.length < 4) {
      toast({
        title: "Invalid PIN",
        description: "PIN must be at least 4 digits",
        variant: "destructive",
      })
      return
    }

    if (pin !== confirmPin) {
      toast({
        title: "PINs don't match",
        description: "Please make sure your PINs match",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "PIN Updated",
        description: "Your parental control PIN has been updated",
      })
    }, 1000)
  }

  const handleSaveSettings = () => {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Settings Saved",
        description: "Your parental control settings have been updated",
      })
    }, 1000)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center mb-8">
            <Shield className="h-8 w-8 mr-3 text-purple-600" />
            <h1 className="text-3xl font-bold">Parental Controls</h1>
          </div>

          <Tabs defaultValue="content">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="content">Content Restrictions</TabsTrigger>
              <TabsTrigger value="time">Time Limits</TabsTrigger>
              <TabsTrigger value="pin">PIN Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="content" className="mt-6 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Filter className="h-5 w-5 mr-2" />
                    Content Filtering
                  </CardTitle>
                  <CardDescription>Control what type of content is accessible</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Kids Mode</Label>
                      <p className="text-sm text-muted-foreground">Only show content appropriate for children</p>
                    </div>
                    <Switch checked={kidsMode} onCheckedChange={setKidsMode} />
                  </div>

                  <div className="space-y-4">
                    <Label className="text-base">Maximum Age Rating</Label>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">G</span>
                      <span className="text-sm">PG</span>
                      <span className="text-sm">PG-13</span>
                      <span className="text-sm">R</span>
                    </div>
                    <Slider value={maxAgeRating} min={0} max={15} step={1} onValueChange={setMaxAgeRating} />
                    <p className="text-sm text-muted-foreground">
                      Current setting:{" "}
                      {maxAgeRating[0] <= 5 ? "G" : maxAgeRating[0] <= 8 ? "PG" : maxAgeRating[0] <= 12 ? "PG-13" : "R"}
                    </p>
                  </div>

                  <div className="space-y-4">
                    <Label className="text-base">Content Filters</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="violence"
                          checked={contentFilters.violence}
                          onCheckedChange={(checked) => setContentFilters({ ...contentFilters, violence: checked })}
                        />
                        <Label htmlFor="violence">Block Violent Content</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="language"
                          checked={contentFilters.language}
                          onCheckedChange={(checked) => setContentFilters({ ...contentFilters, language: checked })}
                        />
                        <Label htmlFor="language">Block Strong Language</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="nudity"
                          checked={contentFilters.nudity}
                          onCheckedChange={(checked) => setContentFilters({ ...contentFilters, nudity: checked })}
                        />
                        <Label htmlFor="nudity">Block Nudity/Sexual Content</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="substances"
                          checked={contentFilters.substances}
                          onCheckedChange={(checked) => setContentFilters({ ...contentFilters, substances: checked })}
                        />
                        <Label htmlFor="substances">Block Drug/Alcohol Use</Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveSettings} disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save Settings"}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="time" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="h-5 w-5 mr-2" />
                    Time Restrictions
                  </CardTitle>
                  <CardDescription>Set time limits and viewing schedules</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Enable Time Restrictions</Label>
                      <p className="text-sm text-muted-foreground">Limit how long and when content can be watched</p>
                    </div>
                    <Switch
                      checked={timeRestrictions.enabled}
                      onCheckedChange={(checked) => setTimeRestrictions({ ...timeRestrictions, enabled: checked })}
                    />
                  </div>

                  {timeRestrictions.enabled && (
                    <>
                      <div className="space-y-2">
                        <Label htmlFor="dailyLimit">Daily Time Limit (minutes)</Label>
                        <div className="flex items-center space-x-4">
                          <Slider
                            id="dailyLimit"
                            value={[timeRestrictions.dailyLimit]}
                            min={30}
                            max={240}
                            step={15}
                            onValueChange={(value) =>
                              setTimeRestrictions({ ...timeRestrictions, dailyLimit: value[0] })
                            }
                          />
                          <span className="w-12 text-center">{timeRestrictions.dailyLimit}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Limit screen time to {timeRestrictions.dailyLimit} minutes per day
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bedtime">Bedtime Cutoff</Label>
                        <Input
                          id="bedtime"
                          type="time"
                          value={timeRestrictions.bedtime}
                          onChange={(e) => setTimeRestrictions({ ...timeRestrictions, bedtime: e.target.value })}
                          className="w-full md:w-40"
                        />
                        <p className="text-sm text-muted-foreground">No viewing allowed after this time</p>
                      </div>
                    </>
                  )}
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSaveSettings} disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save Settings"}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="pin" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lock className="h-5 w-5 mr-2" />
                    Parental Control PIN
                  </CardTitle>
                  <CardDescription>Set a PIN to prevent children from changing settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="pin">New PIN</Label>
                    <Input
                      id="pin"
                      type="password"
                      placeholder="Enter 4-digit PIN"
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      maxLength={4}
                      className="w-full md:w-40"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirmPin">Confirm PIN</Label>
                    <Input
                      id="confirmPin"
                      type="password"
                      placeholder="Confirm PIN"
                      value={confirmPin}
                      onChange={(e) => setConfirmPin(e.target.value)}
                      maxLength={4}
                      className="w-full md:w-40"
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleSavePin} disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save PIN"}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}

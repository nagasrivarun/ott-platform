import { Suspense } from "react"
import { MainNav } from "@/components/navigation/main-nav"
import { ContentCard } from "@/components/content/content-card"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.NEON_NEON_NEON_DATABASE_URL!)

async function searchContent(query: string) {
  try {
    // Search in title and description
    const content = await sql`
      SELECT * FROM content 
      WHERE 
        title ILIKE ${"%" + query + "%"} OR 
        description ILIKE ${"%" + query + "%"}
      ORDER BY 
        CASE 
          WHEN title ILIKE ${"%" + query + "%"} THEN 0 
          ELSE 1 
        END,
        release_year DESC
      LIMIT 24
    `

    return content
  } catch (error) {
    console.error("Error searching content:", error)
    return []
  }
}

interface SearchPageProps {
  searchParams: { q?: string }
}

async function SearchResults({ query }: { query: string }) {
  const results = await searchContent(query)

  if (!results || results.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <h2 className="text-2xl font-bold">No results found</h2>
        <p className="mt-2 text-muted-foreground">We couldn't find any movies or shows matching "{query}"</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
      {results.map((content: any) => (
        <ContentCard
          key={content.id}
          id={content.id}
          title={content.title}
          posterUrl={content.poster_url}
          releaseYear={content.release_year}
          type={content.type}
          maturityRating={content.maturity_rating}
        />
      ))}
    </div>
  )
}

export default function SearchPage({ searchParams }: SearchPageProps) {
  const query = searchParams.q || ""

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <main className="flex-1">
        <div className="container mx-auto py-8">
          <h1 className="mb-6 text-3xl font-bold">{query ? `Search results for "${query}"` : "Search"}</h1>

          {query ? (
            <Suspense fallback={<div className="py-16 text-center">Searching...</div>}>
              <SearchResults query={query} />
            </Suspense>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <h2 className="text-2xl font-bold">Enter a search term</h2>
              <p className="mt-2 text-muted-foreground">Use the search bar or voice search to find movies and shows</p>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

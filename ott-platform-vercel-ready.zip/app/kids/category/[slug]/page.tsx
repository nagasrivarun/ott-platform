import { Suspense } from "react"
import { MainNav } from "@/components/navigation/main-nav"
import { KidsContentCard } from "@/components/kids/kids-content-card"
import { ParentalControlBanner } from "@/components/kids/parental-control-banner"
import { neon } from "@neondatabase/serverless"
import { notFound } from "next/navigation"

const sql = neon(process.env.NEON_NEON_NEON_NEON_DATABASE_URL!)

// Map category slugs to display names and genre IDs
const categoryMap: Record<string, { name: string; genreNames: string[] }> = {
  animation: {
    name: "Animation",
    genreNames: ["Animation"],
  },
  marvel: {
    name: "Marvel",
    genreNames: ["Superhero"],
  },
  disney: {
    name: "Disney",
    genreNames: ["Animation", "Family", "Fantasy"],
  },
  pixar: {
    name: "Pixar",
    genreNames: ["Animation", "Family"],
  },
  dc: {
    name: "DC",
    genreNames: ["Superhero"],
  },
  educational: {
    name: "Educational",
    genreNames: ["Documentary", "Family"],
  },
}

async function getCategoryContent(slug: string) {
  const category = categoryMap[slug]
  if (!category) return []

  try {
    // Get content for this category
    const genreConditions = category.genreNames.map((name) => `g.name = '${name}'`).join(" OR ")

    const content = await sql`
      SELECT DISTINCT c.* FROM content c
      JOIN content_genres cg ON c.id = cg.content_id
      JOIN genres g ON cg.genre_id = g.id
      WHERE 
        (${sql.raw(genreConditions)}) AND
        c.kids_content = true
      ORDER BY c.release_year DESC
      LIMIT 24
    `

    return content || []
  } catch (error) {
    console.error(`Error fetching ${slug} content:`, error)
    return []
  }
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const slug = params.slug.toLowerCase()

  // Check if category exists
  if (!categoryMap[slug]) {
    notFound()
  }

  const categoryName = categoryMap[slug].name

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950">
      <MainNav />
      <ParentalControlBanner />

      <main className="flex-1 container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-purple-800 dark:text-purple-300">{categoryName} for Kids</h1>

        <Suspense fallback={<div className="py-16 text-center">Loading {categoryName} content...</div>}>
          <CategoryContent slug={slug} />
        </Suspense>
      </main>
    </div>
  )
}

async function CategoryContent({ slug }: { slug: string }) {
  const content = await getCategoryContent(slug)

  if (content.length === 0) {
    return (
      <div className="py-16 text-center">
        <p className="text-lg text-muted-foreground">No content found in this category</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
      {content.map((item: any) => (
        <KidsContentCard
          key={item.id}
          id={item.id}
          title={item.title}
          posterUrl={item.poster_url}
          releaseYear={item.release_year}
          type={item.type}
          maturityRating={item.maturity_rating}
        />
      ))}
    </div>
  )
}

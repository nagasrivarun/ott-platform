import { Suspense } from "react"
import { MainNav } from "@/components/navigation/main-nav"
import { KidsHero } from "@/components/kids/kids-hero"
import { KidsContentRow } from "@/components/kids/kids-content-row"
import { KidsCategories } from "@/components/kids/kids-categories"
import { ParentalControlBanner } from "@/components/kids/parental-control-banner"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.NEON_NEON_NEON_NEON_DATABASE_URL!)

async function getKidsContent() {
  try {
    // Get featured kids content
    const featuredContent = await sql`
      SELECT * FROM content 
      WHERE 
        type IN ('MOVIE', 'SHOW') AND 
        kids_content = true AND
        featured = true
      LIMIT 1
    `

    // Get animation content
    const animationContent = await sql`
      SELECT c.* FROM content c
      JOIN content_genres cg ON c.id = cg.content_id
      JOIN genres g ON cg.genre_id = g.id
      WHERE 
        g.name = 'Animation' AND
        c.kids_content = true
      ORDER BY c.release_year DESC
      LIMIT 12
    `

    // Get superhero content
    const superheroContent = await sql`
      SELECT c.* FROM content c
      JOIN content_genres cg ON c.id = cg.content_id
      JOIN genres g ON cg.genre_id = g.id
      WHERE 
        g.name = 'Superhero' AND
        c.kids_content = true
      ORDER BY c.release_year DESC
      LIMIT 12
    `

    // Get family content
    const familyContent = await sql`
      SELECT c.* FROM content c
      JOIN content_genres cg ON c.id = cg.content_id
      JOIN genres g ON cg.genre_id = g.id
      WHERE 
        g.name = 'Family' AND
        c.kids_content = true
      ORDER BY c.release_year DESC
      LIMIT 12
    `

    return {
      featured: featuredContent[0] || null,
      animation: animationContent || [],
      superhero: superheroContent || [],
      family: familyContent || [],
    }
  } catch (error) {
    console.error("Error fetching kids content:", error)
    return {
      featured: null,
      animation: [],
      superhero: [],
      family: [],
    }
  }
}

export default function KidsPage() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950">
      <MainNav />
      <main className="flex-1">
        <Suspense fallback={<div className="h-[50vh] flex items-center justify-center">Loading...</div>}>
          <KidsContent />
        </Suspense>
      </main>
    </div>
  )
}

async function KidsContent() {
  const { featured, animation, superhero, family } = await getKidsContent()

  return (
    <>
      <ParentalControlBanner />

      {featured && (
        <KidsHero
          id={featured.id}
          title={featured.title}
          description={featured.description}
          backdropUrl={featured.backdrop_url}
          ageRating={featured.maturity_rating}
        />
      )}

      <div className="container mx-auto px-4 py-8">
        <KidsCategories />

        <div className="space-y-12 mt-8">
          <KidsContentRow
            title="Animation Movies & Shows"
            contents={animation}
            emptyMessage="No animation content found"
          />

          <KidsContentRow title="Superhero Adventures" contents={superhero} emptyMessage="No superhero content found" />

          <KidsContentRow title="Family Favorites" contents={family} emptyMessage="No family content found" />
        </div>
      </div>
    </>
  )
}

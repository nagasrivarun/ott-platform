import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json()

    if (!query || typeof query !== "string") {
      return NextResponse.json({ error: "Query parameter is required and must be a string" }, { status: 400 })
    }

    const systemPrompt = `You are GlobalStream's AI voice assistant. 
    You help users find movies and TV shows, answer questions about content, 
    and provide recommendations. Keep responses brief and conversational.
    If asked about a specific movie or show, provide a short summary and key information.
    If asked for recommendations, suggest relevant titles based on the query.
    Always maintain a helpful, friendly tone.`

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      prompt: query,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("Error in voice assistant API:", error)
    return NextResponse.json({ error: "An error occurred processing your request" }, { status: 500 })
  }
}

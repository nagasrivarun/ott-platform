import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "../../auth/[...nextauth]/route"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.NEON_NEON_NEON_NEON_DATABASE_URL!)

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    // Sample kids content data
    const kidsContent = [
      {
        title: "Super Hero Adventures",
        description: "Join your favorite heroes on exciting adventures as they learn about teamwork and friendship.",
        type: "SHOW",
        release_year: 2023,
        maturity_rating: "G",
        poster_url: "/placeholder.svg?height=450&width=300&text=Super+Hero+Adventures",
        backdrop_url: "/placeholder.svg?height=1080&width=1920&text=Super+Hero+Adventures",
        kids_content: true,
        featured: true,
        genres: ["Animation", "Superhero", "Family"],
      },
      {
        title: "The Magic Kingdom",
        description: "A magical adventure in an enchanted kingdom where animals talk and dreams come true.",
        type: "MOVIE",
        release_year: 2022,
        maturity_rating: "G",
        poster_url: "/placeholder.svg?height=450&width=300&text=Magic+Kingdom",
        backdrop_url: "/placeholder.svg?height=1080&width=1920&text=Magic+Kingdom",
        kids_content: true,
        genres: ["Animation", "Family", "Fantasy"],
      },
      {
        title: "Robot Friends",
        description: "A group of friendly robots teach children about science, technology, and problem-solving.",
        type: "SHOW",
        release_year: 2021,
        maturity_rating: "G",
        poster_url: "/placeholder.svg?height=450&width=300&text=Robot+Friends",
        backdrop_url: "/placeholder.svg?height=1080&width=1920&text=Robot+Friends",
        kids_content: true,
        genres: ["Animation", "Family", "Educational"],
      },
      {
        title: "Superhero Academy",
        description: "Young superheroes learn to control their powers and use them for good at a special school.",
        type: "MOVIE",
        release_year: 2023,
        maturity_rating: "PG",
        poster_url: "/placeholder.svg?height=450&width=300&text=Superhero+Academy",
        backdrop_url: "/placeholder.svg?height=1080&width=1920&text=Superhero+Academy",
        kids_content: true,
        genres: ["Superhero", "Family", "Action"],
      },
      {
        title: "Dinosaur Explorers",
        description: "Join a team of young explorers as they travel back in time to learn about dinosaurs.",
        type: "SHOW",
        release_year: 2020,
        maturity_rating: "G",
        poster_url: "/placeholder.svg?height=450&width=300&text=Dinosaur+Explorers",
        backdrop_url: "/placeholder.svg?height=1080&width=1920&text=Dinosaur+Explorers",
        kids_content: true,
        genres: ["Animation", "Educational", "Adventure"],
      },
      {
        title: "Space Pets",
        description: "Adorable alien pets have amazing adventures across the galaxy.",
        type: "MOVIE",
        release_year: 2021,
        maturity_rating: "G",
        poster_url: "/placeholder.svg?height=450&width=300&text=Space+Pets",
        backdrop_url: "/placeholder.svg?height=1080&width=1920&text=Space+Pets",
        kids_content: true,
        genres: ["Animation", "Family", "Comedy"],
      },
    ]

    // Insert content and link genres
    for (const content of kidsContent) {
      // Check if content already exists
      const existingContent = await sql`
        SELECT id FROM content WHERE title = ${content.title} AND release_year = ${content.release_year}
      `

      if (existingContent.length === 0) {
        // Insert content
        const [newContent] = await sql`
          INSERT INTO content (
            title, description, type, release_year, maturity_rating, 
            poster_url, backdrop_url, kids_content, featured
          ) VALUES (
            ${content.title}, ${content.description}, ${content.type}, 
            ${content.release_year}, ${content.maturity_rating}, 
            ${content.poster_url}, ${content.backdrop_url}, 
            ${content.kids_content}, ${content.featured || false}
          )
          RETURNING id
        `

        // Link genres
        for (const genreName of content.genres) {
          // Get genre ID
          const genres = await sql`SELECT id FROM genres WHERE name = ${genreName}`

          if (genres.length > 0) {
            const genreId = genres[0].id

            // Link content to genre
            await sql`
              INSERT INTO content_genres (content_id, genre_id)
              VALUES (${newContent.id}, ${genreId})
            `
          }
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: `Successfully seeded ${kidsContent.length} kids content items`,
    })
  } catch (error) {
    console.error("Error seeding kids content:", error)
    return new NextResponse("Internal Error", { status: 500 })
  }
}

import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "../../auth/[...nextauth]/route"
import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.NEON_NEON_NEON_NEON_DATABASE_URL!)

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== "ADMIN") {
      return new NextResponse("Unauthorized", { status: 401 })
    }

    // Add kids_content column to content table if it doesn't exist
    await sql`
      DO $$ 
      BEGIN
        IF NOT EXISTS (
          SELECT FROM information_schema.columns 
          WHERE table_name = 'content' AND column_name = 'kids_content'
        ) THEN
          ALTER TABLE content ADD COLUMN kids_content BOOLEAN DEFAULT false;
        END IF;
      END $$;
    `

    // Add Superhero genre if it doesn't exist
    await sql`
      INSERT INTO genres (name)
      SELECT 'Superhero'
      WHERE NOT EXISTS (
        SELECT 1 FROM genres WHERE name = 'Superhero'
      );
    `

    // Add Family genre if it doesn't exist
    await sql`
      INSERT INTO genres (name)
      SELECT 'Family'
      WHERE NOT EXISTS (
        SELECT 1 FROM genres WHERE name = 'Family'
      );
    `

    return NextResponse.json({
      success: true,
      message: "Database schema updated successfully for kids content",
    })
  } catch (error) {
    console.error("Error updating schema:", error)
    return new NextResponse("Internal Error", { status: 500 })
  }
}

"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Mic, MicOff, X, Volume2, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Declare SpeechRecognition
declare var webkitSpeechRecognition: any
declare var SpeechRecognition: any

export function VoiceAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [response, setResponse] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null)
  const { toast } = useToast()

  // Initialize speech recognition
  useEffect(() => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      console.error("Speech recognition not supported in this browser")
      return
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    recognitionRef.current = new SpeechRecognition()

    const recognition = recognitionRef.current
    recognition.continuous = false
    recognition.interimResults = true
    recognition.lang = "en-US"

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onresult = (event) => {
      const current = event.resultIndex
      const result = event.results[current]
      const transcriptText = result[0].transcript
      setTranscript(transcriptText)
    }

    recognition.onend = () => {
      setIsListening(false)
      if (transcript.trim()) {
        processQuery(transcript)
      }
    }

    recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error)
      setIsListening(false)
      toast({
        title: "Voice Recognition Error",
        description: `Error: ${event.error}. Please try again.`,
        variant: "destructive",
      })
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (isSpeaking) {
        window.speechSynthesis.cancel()
      }
    }
  }, [toast])

  // Process the user's query
  const processQuery = async (query: string) => {
    if (!query.trim()) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/voice-assistant", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      })

      if (!response.ok) {
        throw new Error("Failed to get response from assistant")
      }

      const data = await response.json()
      setResponse(data.response)
      speakResponse(data.response)
    } catch (error) {
      console.error("Error processing query:", error)
      toast({
        title: "Error",
        description: "Failed to process your request. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Speak the assistant's response
  const speakResponse = (text: string) => {
    if (!("speechSynthesis" in window)) {
      console.error("Speech synthesis not supported in this browser")
      return
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel()

    utteranceRef.current = new SpeechSynthesisUtterance(text)

    // Set preferred voice (English)
    const voices = window.speechSynthesis.getVoices()
    const englishVoice = voices.find((voice) => voice.lang.includes("en-"))
    if (englishVoice) {
      utteranceRef.current.voice = englishVoice
    }

    utteranceRef.current.rate = 1.0
    utteranceRef.current.pitch = 1.0
    utteranceRef.current.volume = 1.0

    utteranceRef.current.onstart = () => {
      setIsSpeaking(true)
    }

    utteranceRef.current.onend = () => {
      setIsSpeaking(false)
    }

    utteranceRef.current.onerror = (event) => {
      console.error("Speech synthesis error", event)
      setIsSpeaking(false)
    }

    window.speechSynthesis.speak(utteranceRef.current)
  }

  const toggleListening = () => {
    if (!recognitionRef.current) return

    if (isListening) {
      recognitionRef.current.stop()
    } else {
      setTranscript("")
      setResponse("")
      recognitionRef.current.start()
    }
  }

  const stopSpeaking = () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const toggleAssistant = () => {
    setIsOpen(!isOpen)
    if (!isOpen) {
      setTranscript("")
      setResponse("")
    } else {
      if (isListening && recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (isSpeaking) {
        window.speechSynthesis.cancel()
      }
    }
  }

  return (
    <>
      <Button className="fixed bottom-4 right-4 rounded-full h-12 w-12 p-0 shadow-lg" onClick={toggleAssistant}>
        <Mic className="h-6 w-6" />
      </Button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>GlobalStream Voice Assistant</CardTitle>
              <Button variant="ghost" size="icon" onClick={toggleAssistant}>
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="min-h-[100px] p-4 bg-muted rounded-md">
                {transcript ? (
                  <p className="text-sm">You: {transcript}</p>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    {isListening ? "Listening..." : "Click the microphone and ask a question..."}
                  </p>
                )}

                {isLoading && (
                  <div className="flex justify-center my-2">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                )}

                {response && (
                  <div className="mt-4">
                    <p className="text-sm font-medium">Assistant:</p>
                    <p className="text-sm">{response}</p>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button
                variant={isListening ? "destructive" : "default"}
                onClick={toggleListening}
                disabled={isLoading}
                className="flex items-center space-x-2"
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                <span>{isListening ? "Stop" : "Ask"}</span>
              </Button>

              {isSpeaking && (
                <Button variant="outline" onClick={stopSpeaking}>
                  <Volume2 className="h-4 w-4 mr-2" />
                  Stop Audio
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      )}
    </>
  )
}

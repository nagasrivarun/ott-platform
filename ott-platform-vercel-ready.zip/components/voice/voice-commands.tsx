"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Mic, MicOff } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface VoiceCommandsProps {
  onCommand: (command: string) => void
  commands: string[]
  isActive?: boolean
}

export function VoiceCommands({ onCommand, commands, isActive = false }: VoiceCommandsProps) {
  const [isListening, setIsListening] = useState(isActive)
  const [commandDetected, setCommandDetected] = useState<string | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Check if browser supports SpeechRecognition
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      console.error("Speech recognition not supported in this browser")
      return
    }

    // Initialize speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const recognition = new SpeechRecognition()
    recognitionRef.current = recognition

    recognition.continuous = true
    recognition.interimResults = false
    recognition.lang = "en-US"

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onresult = (event) => {
      const last = event.results.length - 1
      const transcript = event.results[last][0].transcript.trim().toLowerCase()

      console.log("Voice command detected:", transcript)

      // Check if the transcript matches any of our commands
      const matchedCommand = commands.find((command) => transcript.includes(command.toLowerCase()))

      if (matchedCommand) {
        setCommandDetected(matchedCommand)
        onCommand(matchedCommand)

        toast({
          title: "Command Detected",
          description: `Executing: ${matchedCommand}`,
        })
      }
    }

    recognition.onend = () => {
      setIsListening(false)
      // Restart listening if it was active
      if (isActive && recognitionRef.current) {
        recognitionRef.current.start()
      }
    }

    recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error)
      setIsListening(false)

      if (event.error !== "no-speech") {
        toast({
          title: "Voice Command Error",
          description: `Error: ${event.error}. Please try again.`,
          variant: "destructive",
        })
      }
    }

    // Start listening if isActive is true
    if (isActive && recognitionRef.current) {
      recognitionRef.current.start()
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [commands, isActive, onCommand, toast])

  // Update listening state when isActive prop changes
  useEffect(() => {
    if (isActive && !isListening && recognitionRef.current) {
      recognitionRef.current.start()
    } else if (!isActive && isListening && recognitionRef.current) {
      recognitionRef.current.stop()
    }
  }, [isActive, isListening])

  const toggleListening = () => {
    if (!recognitionRef.current) return

    if (isListening) {
      recognitionRef.current.stop()
    } else {
      recognitionRef.current.start()
    }
  }

  return (
    <div>
      <Button
        variant={isListening ? "default" : "outline"}
        size="sm"
        onClick={toggleListening}
        className={`flex items-center space-x-1 ${isListening ? "bg-red-500 hover:bg-red-600" : ""}`}
      >
        {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
        <span>{isListening ? "Voice Active" : "Enable Voice"}</span>
      </Button>

      {commandDetected && (
        <div className="mt-2 text-sm text-muted-foreground">
          Last command: <span className="font-medium">{commandDetected}</span>
        </div>
      )}
    </div>
  )
}

"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Volume2, VolumeX, Pause, Play } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface TextToSpeechProps {
  text: string
  label?: string
}

export function TextToSpeech({ text, label = "Listen" }: TextToSpeechProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [isSpeechSupported, setIsSpeechSupported] = useState(true)
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Check if browser supports speech synthesis
    if (!("speechSynthesis" in window)) {
      console.error("Speech synthesis not supported in this browser")
      setIsSpeechSupported(false)
      return
    }

    // Initialize speech synthesis
    utteranceRef.current = new SpeechSynthesisUtterance(text)

    // Set preferred voice (English)
    const voices = window.speechSynthesis.getVoices()
    const englishVoice = voices.find((voice) => voice.lang.includes("en-"))
    if (englishVoice) {
      utteranceRef.current.voice = englishVoice
    }

    utteranceRef.current.rate = 1.0
    utteranceRef.current.pitch = 1.0
    utteranceRef.current.volume = 1.0

    // Event handlers
    utteranceRef.current.onend = () => {
      setIsPlaying(false)
      setIsPaused(false)
    }

    utteranceRef.current.onerror = (event) => {
      console.error("Speech synthesis error", event)
      setIsPlaying(false)
      setIsPaused(false)
      toast({
        title: "Text-to-Speech Error",
        description: "There was an error playing the audio. Please try again.",
        variant: "destructive",
      })
    }

    // Get voices when they're loaded (they load asynchronously)
    window.speechSynthesis.onvoiceschanged = () => {
      if (utteranceRef.current) {
        const voices = window.speechSynthesis.getVoices()
        const englishVoice = voices.find((voice) => voice.lang.includes("en-"))
        if (englishVoice) {
          utteranceRef.current.voice = englishVoice
        }
      }
    }

    return () => {
      if (isPlaying) {
        window.speechSynthesis.cancel()
      }
    }
  }, [text, toast])

  const toggleSpeech = () => {
    if (!isSpeechSupported || !utteranceRef.current) return

    if (isPlaying) {
      if (isPaused) {
        window.speechSynthesis.resume()
        setIsPaused(false)
      } else {
        window.speechSynthesis.pause()
        setIsPaused(true)
      }
    } else {
      window.speechSynthesis.cancel() // Cancel any ongoing speech
      window.speechSynthesis.speak(utteranceRef.current)
      setIsPlaying(true)
      setIsPaused(false)
    }
  }

  const stopSpeech = () => {
    if (isPlaying) {
      window.speechSynthesis.cancel()
      setIsPlaying(false)
      setIsPaused(false)
    }
  }

  if (!isSpeechSupported) {
    return null
  }

  return (
    <div className="flex items-center space-x-2">
      <Button variant="outline" size="sm" onClick={toggleSpeech} className="flex items-center space-x-1">
        {isPlaying ? (
          isPaused ? (
            <Play className="h-4 w-4" />
          ) : (
            <Pause className="h-4 w-4" />
          )
        ) : (
          <Volume2 className="h-4 w-4" />
        )}
        <span>{isPlaying ? (isPaused ? "Resume" : "Pause") : label}</span>
      </Button>

      {isPlaying && (
        <Button variant="ghost" size="sm" onClick={stopSpeech}>
          <VolumeX className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}

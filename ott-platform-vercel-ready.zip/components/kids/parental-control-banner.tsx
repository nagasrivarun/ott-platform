"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Shield, X } from "lucide-react"

export function ParentalControlBanner() {
  const [isVisible, setIsVisible] = useState(true)

  if (!isVisible) return null

  return (
    <div className="bg-blue-100 dark:bg-blue-900 border-b border-blue-200 dark:border-blue-800 p-3">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-blue-600 dark:text-blue-300" />
          <p className="text-sm text-blue-800 dark:text-blue-200">
            <span className="font-medium">Kids Mode Active:</span> Content is filtered for children.
            <Button variant="link" className="text-blue-600 dark:text-blue-300 p-0 h-auto text-sm" asChild>
              <a href="/profile/parental-controls"> Adjust parental controls</a>
            </Button>
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="text-blue-600 dark:text-blue-300 h-8 w-8 p-0 rounded-full"
          onClick={() => setIsVisible(false)}
        >
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </Button>
      </div>
    </div>
  )
}

"use client"

import { useRef } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { KidsContentCard } from "@/components/kids/kids-content-card"

interface KidsContentRowProps {
  title: string
  contents: any[]
  emptyMessage?: string
}

export function KidsContentRow({ title, contents, emptyMessage = "No content available" }: KidsContentRowProps) {
  const rowRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current
      const scrollTo = direction === "left" ? scrollLeft - clientWidth / 2 : scrollLeft + clientWidth / 2

      rowRef.current.scrollTo({
        left: scrollTo,
        behavior: "smooth",
      })
    }
  }

  if (contents.length === 0) {
    return (
      <div className="py-8 text-center">
        <p className="text-muted-foreground">{emptyMessage}</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-purple-800 dark:text-purple-300">{title}</h2>

      <div className="relative group">
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-0 top-1/2 z-10 h-8 w-8 -translate-y-1/2 rounded-full bg-white/80 text-purple-800 opacity-0 shadow-md transition-opacity group-hover:opacity-100 dark:bg-gray-800/80 dark:text-purple-300"
          onClick={() => scroll("left")}
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>

        <div ref={rowRef} className="flex space-x-4 overflow-x-scroll scrollbar-hide py-4 pb-8">
          {contents.map((content) => (
            <div key={content.id} className="flex-shrink-0 w-[180px] transition-transform duration-300 hover:scale-105">
              <KidsContentCard
                id={content.id}
                title={content.title}
                posterUrl={content.poster_url}
                releaseYear={content.release_year}
                type={content.type}
                maturityRating={content.maturity_rating}
              />
            </div>
          ))}
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="absolute right-0 top-1/2 z-10 h-8 w-8 -translate-y-1/2 rounded-full bg-white/80 text-purple-800 opacity-0 shadow-md transition-opacity group-hover:opacity-100 dark:bg-gray-800/80 dark:text-purple-300"
          onClick={() => scroll("right")}
          aria-label="Scroll right"
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}

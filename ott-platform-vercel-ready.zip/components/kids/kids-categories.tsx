import Link from "next/link"

const categories = [
  {
    name: "Animation",
    icon: "🎬",
    color: "bg-blue-100 dark:bg-blue-900",
    textColor: "text-blue-800 dark:text-blue-200",
    href: "/kids/category/animation",
  },
  {
    name: "Marvel",
    icon: "🦸‍♂️",
    color: "bg-red-100 dark:bg-red-900",
    textColor: "text-red-800 dark:text-red-200",
    href: "/kids/category/marvel",
  },
  {
    name: "Disney",
    icon: "🏰",
    color: "bg-purple-100 dark:bg-purple-900",
    textColor: "text-purple-800 dark:text-purple-200",
    href: "/kids/category/disney",
  },
  {
    name: "Pixar",
    icon: "🚀",
    color: "bg-yellow-100 dark:bg-yellow-900",
    textColor: "text-yellow-800 dark:text-yellow-200",
    href: "/kids/category/pixar",
  },
  {
    name: "DC",
    icon: "🦇",
    color: "bg-gray-100 dark:bg-gray-800",
    textColor: "text-gray-800 dark:text-gray-200",
    href: "/kids/category/dc",
  },
  {
    name: "Educational",
    icon: "📚",
    color: "bg-green-100 dark:bg-green-900",
    textColor: "text-green-800 dark:text-green-200",
    href: "/kids/category/educational",
  },
]

export function KidsCategories() {
  return (
    <div className="py-6">
      <h2 className="text-2xl font-bold mb-4 text-purple-800 dark:text-purple-300">Categories</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
        {categories.map((category) => (
          <Link
            key={category.name}
            href={category.href}
            className={`flex flex-col items-center justify-center p-4 rounded-xl ${category.color} transition-transform hover:scale-105`}
          >
            <span className="text-3xl mb-2">{category.icon}</span>
            <span className={`font-medium ${category.textColor}`}>{category.name}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}

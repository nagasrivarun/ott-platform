"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Play, Info } from "lucide-react"
import { TextToSpeech } from "@/components/voice/text-to-speech"

interface KidsHeroProps {
  id: string
  title: string
  description: string
  backdropUrl: string
  ageRating?: string
}

export function KidsHero({ id, title, description, backdropUrl, ageRating }: KidsHeroProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="relative h-[60vh] w-full overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Background Image with Animation */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-transform duration-10000 ease-in-out"
        style={{
          backgroundImage: `url(${backdropUrl || "/placeholder.svg?height=1080&width=1920"})`,
          transform: isHovered ? "scale(1.05)" : "scale(1)",
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 via-purple-900/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-center px-8 md:px-16 max-w-3xl">
        <div className="animate-bounce-slow absolute -top-16 right-16 hidden md:block">
          <img src="/placeholder.svg?height=150&width=150" alt="Character" className="h-32 w-32 object-contain" />
        </div>

        <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white drop-shadow-lg">{title}</h1>

        {ageRating && (
          <div className="inline-block mb-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
            {ageRating}
          </div>
        )}

        <p className="text-lg mb-8 text-white drop-shadow-md line-clamp-3">{description}</p>

        <div className="flex flex-wrap gap-4">
          <Button size="lg" className="gap-2 bg-purple-600 hover:bg-purple-700" asChild>
            <Link href={`/content/${id}`}>
              <Play className="h-5 w-5" /> Watch Now
            </Link>
          </Button>

          <Button variant="outline" size="lg" className="gap-2 bg-white/20 backdrop-blur-sm hover:bg-white/30" asChild>
            <Link href={`/content/${id}`}>
              <Info className="h-5 w-5" /> More Info
            </Link>
          </Button>

          <div className="mt-2 md:mt-0">
            <TextToSpeech text={description} label="Hear About This" />
          </div>
        </div>
      </div>
    </div>
  )
}

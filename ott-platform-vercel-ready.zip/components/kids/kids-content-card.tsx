import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"

interface KidsContentCardProps {
  id: string
  title: string
  posterUrl: string
  releaseYear: number
  type: string
  maturityRating?: string
}

export function KidsContentCard({ id, title, posterUrl, releaseYear, type, maturityRating }: KidsContentCardProps) {
  return (
    <Card className="group overflow-hidden rounded-xl border-2 border-purple-200 transition-all hover:border-purple-400 hover:shadow-lg dark:border-purple-900 dark:hover:border-purple-700">
      <Link href={`/content/${id}`}>
        <div className="relative aspect-[2/3] overflow-hidden rounded-t-lg">
          <img
            src={posterUrl || `/placeholder.svg?height=450&width=300`}
            alt={title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
          {maturityRating && (
            <div className="absolute bottom-2 left-2 rounded-full bg-green-500 px-2 py-0.5 text-xs font-medium text-white">
              {maturityRating}
            </div>
          )}
        </div>
        <CardContent className="p-3 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950">
          <h3 className="line-clamp-1 font-bold text-purple-800 dark:text-purple-300">{title}</h3>
          <div className="mt-1 flex items-center justify-between text-sm text-purple-600 dark:text-purple-400">
            <span>{releaseYear}</span>
            <span className="capitalize">{type}</span>
          </div>
        </CardContent>
      </Link>
    </Card>
  )
}
